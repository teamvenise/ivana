$(document).ready(function(){
     window.sr = ScrollReveal({ duration: 2000 });  

      var hero = {
        origin   : "bottom",
        distance : "100px",
        duration : 1500,
        scale    : 0,
        reset: false,
      }

      var intro = {
        origin   : "top",
        distance : "10px",
        duration : 1500,
        delay    : 500,
        scale    : 1,
        reset: false,
      }

      var github = {
        origin   : "top",
        distance : "200px",
        duration : 600,
        delay    : 500,
        scale    : 0,
        reset: false,
      }
    var bottom = {
        origin   : "bottom",
        distance : "300px",
        duration : 1000,
        delay    : 500,
        scale    : 0,
        reset: false,
      }
      var block = {
        reset: false,
        viewOffset: { top: 64 }
      }

      
      //sr.reveal(".processList li", intro)
      sr.reveal(".bloc_maisonHome .col-sm-6", intro)
      sr.reveal(".bloc_maisonHome .col-sm-6", block, 200)
      
      sr.reveal(".banner .text_header", bottom)
      sr.reveal(".bloc_history_home .container", bottom)
    
    $(".buttonDetails").click(function(){
        $(this).toggleClass("in");
        $(this).parent(".details_bloc").toggleClass("open");
        $(this).parents(".bloc_details").toggleClass("open");
    });
    
    
    $('#datetimepickerTana').datetimepicker({
        locale:'fr',
        inline: true,
        format: 'DD.MM.YYYY',
        minDate: new Date(),
        useCurrent: true,
        sideBySide: true
    }).on('dp.change',function(event){
        //var dateStr = $("#datetimepicker12").val();
        var dateVal = $("#datetimepickerTana").val();
        console.log(dateVal);
        $("#inputDateTana").attr("value",dateVal);
        $('#rdvTana').modal('show');
    
    
        $('#rdvTana').on('shown.bs.modal', function () {
             $("#inputDateTana").attr("value",dateVal); 
             
        });
        $('#rdvTana').on('hidden.bs.modal', function () {
            console.log("close");
          $("#inputDateTana").attr("value",""); 
        });
    });
    $('#datetimepickerParis').datetimepicker({
        locale:'fr',
        inline: true,
        format: 'DD.MM.YYYY',
        minDate: moment("13.01.2018", "DD.MM.YYYY"),
        maxDate: moment("14.02.2018", "DD.MM.YYYY"),
        useCurrent: true,
        sideBySide: true
    }).on('dp.change',function(event){
        var dateVal = $("#datetimepickerParis").val();
        console.log(dateVal);
        $("#inputDateParis").attr("value",dateVal);
        $('#rdvParis').modal('show');
    
    
        $('#rdvParis').on('shown.bs.modal', function () {
             $("#inputDateParis").attr("value",dateVal); 
             
        });
        $('#rdvParis').on('hidden.bs.modal', function () {
            console.log("close");
          $("#inputDateParis").attr("value",""); 
        });
    });
    
    
   
      
    
      $(".curr_date").html( moment().format('D') );
      $(".curr_mounth").html( moment().format('MMMM') );
      
      $("#checkParis").click(function(){
        $(this).parents(".checkCountry").addClass("hide");
        $(".getDateParis").removeClass("hide");
        $(".back").removeClass("hide");
     });
     $("#checkTana").click(function(){
        $(this).parents(".checkCountry").addClass("hide");
        $(".getDateTana").removeClass("hide");
        $(".back").removeClass("hide");
     });
     $(".back").click(function(){
        $(this).addClass("hide");
        $(".getDateParis").addClass("hide");
        $(".getDateTana").addClass("hide");
        $(".checkCountry").removeClass("hide");
     });
     
     $(".menu-item-has-children").hover(function(){
            $(this).children(".sub-menu").toggleClass("in");
            $(this).toggleClass("in");
        });
     $(".menu-item-has-children").click(function(){
            $(this).children(".sub-menu").toggleClass("in");
            $(this).toggleClass("in");
        });
     $('#inputDateTana,#inputpays,#inputDateParis').attr('disabled', 'disabled');
     
     $(".navbar-header").click(function(){
            $(".mehuHeader").toggleClass("open");
            $(this).toggleClass("open");
        });
     
});