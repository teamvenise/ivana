$(document).on('ready', function () {
         $('.rat_in').rating({displayOnly: true});
    });