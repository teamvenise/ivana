<?php get_header();?>
     
    
    <main class="main_home page">
        <?php while(have_posts()) : the_post(); ?>
        <div class="container">
            <?php the_content();?>
        </div>
        
        <?php
		endwhile;
		wp_reset_query();
		?>
<?php get_footer();?>