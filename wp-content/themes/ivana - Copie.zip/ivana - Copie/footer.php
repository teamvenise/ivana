        <section class="mapHome relative">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d120799.5785927135!2d47.44247405154489!3d-18.88766538820728!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x21f07de34f1f4eb3%3A0xdf110608bcc082f9!2sTananarive!5e0!3m2!1sfr!2smg!4v1512022670549" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
            <div class="absolute">
                <div class="contact_map">
                    <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut nisi massa.</p>
                    <hr />
                    <ul class="socialMap">
                        <li><a href="mailto:">salama@ivana.mg</a></li>
                        <li><a href="#">/ivana.immobilier</a></li>
                        <li><a href="#">+261 34 70 830 02</a></li>
                        <li><a href="#">@ivana_home</a></li>
                    </ul>
                </div>
            </div>
        </section>
    </main>
    <footer>
        <div class="container text-center">
            &copy; Ivana 2017, Tous Droits Réservés
        </div>
    </footer>
    
    <?php  wp_footer();?>
</body>
</html>